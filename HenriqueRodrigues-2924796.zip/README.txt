Claire, inside the documentation Folder you can see the PDF for the design asked. (And a tiny website with the how to use documentation)
this is the Root for the software, it will expect all the dictionaries to be under the filteredDics folder here.
All the java files are inside the src folder (following the path).
I'm sorry if this is way bigger than expected, I spent dozens of hours on this, and you look supportive of extra features.
But I may have stepped over the line.
I tried to mark down the code of the proper assigment.

Don't bother reading everything else if you don't want to.

Thank you,
Henrique Rodrigues
